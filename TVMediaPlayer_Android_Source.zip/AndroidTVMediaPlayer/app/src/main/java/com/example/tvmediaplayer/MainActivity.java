package com.example.tvmediaplayer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private VideoView videoView;
    private LinearLayout audioPanel;
    private TextView tvNowPlaying, tvStatus;
    private Button btnPlay, btnShuffle, btnRepeat;

    private final List<MediaEntry> playlist = new ArrayList<>();
    private int currentIndex = -1;
    private boolean isShuffle = false;
    private int repeatMode = 0; // 0=OFF 1=ONE 2=ALL
    private boolean isAudioMode = false;

    static class MediaEntry {
        Uri uri;
        String name;
        boolean isVideo;
        MediaEntry(Uri u, String n, boolean v) { uri = u; name = n; isVideo = v; }
    }

    private final ActivityResultLauncher<String[]> addLauncher =
        registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
            if (uris == null) return;
            for (Uri uri : uris) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) {}
                String name = getFileName(uri);
                boolean isVideo = isVideoFile(name, uri);
                playlist.add(new MediaEntry(uri, name, isVideo));
            }
            updateStatus();
            Toast.makeText(this, "Adăugat " + uris.size() + " fișier(e)", Toast.LENGTH_SHORT).show();
        });

    private final ActivityResultLauncher<String[]> selectLauncher =
        registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null) return;
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            String name = getFileName(uri);
            boolean isVideo = isVideoFile(name, uri);
            playlist.clear();
            playlist.add(new MediaEntry(uri, name, isVideo));
            currentIndex = 0;
            playCurrent();
        });

    private final ActivityResultLauncher<String[]> permLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> {});

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoView = findViewById(R.id.videoView);
        audioPanel = findViewById(R.id.audioPanel);
        tvNowPlaying = findViewById(R.id.tvNowPlaying);
        tvStatus = findViewById(R.id.tvStatus);
        btnPlay = findViewById(R.id.btnPlay);
        btnShuffle = findViewById(R.id.btnShuffle);
        btnRepeat = findViewById(R.id.btnRepeat);

        findViewById(R.id.btnAdd).setOnClickListener(v ->
            addLauncher.launch(new String[]{"video/*", "audio/*"}));
        findViewById(R.id.btnVideo).setOnClickListener(v ->
            selectLauncher.launch(new String[]{"video/*"}));
        findViewById(R.id.btnAudio).setOnClickListener(v ->
            selectLauncher.launch(new String[]{"audio/*"}));
        btnPlay.setOnClickListener(v -> togglePlay());
        findViewById(R.id.btnStop).setOnClickListener(v -> stopPlay());
        btnShuffle.setOnClickListener(v -> {
            isShuffle = !isShuffle;
            btnShuffle.setText(isShuffle ? "Shuffle ON" : "Shuffle");
            if (isShuffle && playlist.size() > 1) Collections.shuffle(playlist);
        });
        btnRepeat.setOnClickListener(v -> {
            repeatMode = (repeatMode + 1) % 3;
            String[] labels = {"Repeat", "Repeat 1", "Repeat All"};
            btnRepeat.setText(labels[repeatMode]);
        });

        videoView.setOnCompletionListener(mp -> {
            if (repeatMode == 1) {
                videoView.seekTo(0);
                videoView.start();
            } else if (repeatMode == 2 || currentIndex < playlist.size() - 1) {
                playNext();
            } else {
                stopPlay();
            }
        });

        requestPerms();
        findViewById(R.id.btnAdd).requestFocus();
    }


    private void requestPerms() {
        List<String> perms = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VIDEO);
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_AUDIO);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!perms.isEmpty()) permLauncher.launch(perms.toArray(new String[0]));
    }

    private void playCurrent() {
        if (currentIndex < 0 || currentIndex >= playlist.size()) return;
        MediaEntry e = playlist.get(currentIndex);
        videoView.setVideoURI(e.uri);
        if (e.isVideo) {
            videoView.setVisibility(View.VISIBLE);
            audioPanel.setVisibility(View.GONE);
            isAudioMode = false;
        } else {
            videoView.setVisibility(View.INVISIBLE);
            audioPanel.setVisibility(View.VISIBLE);
            tvNowPlaying.setText(e.name);
            isAudioMode = true;
        }
        videoView.start();
        btnPlay.setText("Pause");
        updateStatus();
    }

    private void togglePlay() {
        if (playlist.isEmpty()) {
            Toast.makeText(this, "Playlist gol", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentIndex < 0) {
            currentIndex = 0;
            playCurrent();
            return;
        }
        if (videoView.isPlaying()) {
            videoView.pause();
            btnPlay.setText("Play");
        } else {
            videoView.start();
            btnPlay.setText("Pause");
        }
    }

    private void stopPlay() {
        videoView.stopPlayback();
        currentIndex = -1;
        videoView.setVisibility(View.VISIBLE);
        audioPanel.setVisibility(View.GONE);
        btnPlay.setText("Play");
        updateStatus();
    }

    private void playNext() {
        if (playlist.isEmpty()) return;
        if (isShuffle) currentIndex = (int) (Math.random() * playlist.size());
        else currentIndex = (currentIndex + 1) % playlist.size();
        playCurrent();
    }

    private void playPrev() {
        if (playlist.isEmpty()) return;
        if (isShuffle) currentIndex = (int) (Math.random() * playlist.size());
        else currentIndex = currentIndex <= 0 ? playlist.size() - 1 : currentIndex - 1;
        playCurrent();
    }

    private void updateStatus() {
        if (playlist.isEmpty()) {
            tvStatus.setText("Adaugă fișiere media");
        } else if (currentIndex >= 0) {
            MediaEntry e = playlist.get(currentIndex);
            tvStatus.setText("▶ " + e.name + "  (" + (currentIndex + 1) + "/" + playlist.size() + ")");
        } else {
            tvStatus.setText("Playlist: " + playlist.size() + " fișier(e)");
        }
    }

    private String getFileName(Uri uri) {
        String name = "Media";
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {}
        return name;
    }

    private boolean isVideoFile(String name, Uri uri) {
        String lower = name.toLowerCase();
        if (lower.matches(".*\\.(mp4|mkv|avi|webm|mov|3gp|m4v)$")) return true;
        if (lower.matches(".*\\.(mp3|m4a|aac|flac|wav|ogg|wma|opus)$")) return false;
        String mime = getContentResolver().getType(uri);
        return mime != null && mime.startsWith("video/");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                togglePlay(); return true;
            case KeyEvent.KEYCODE_MEDIA_STOP:
                stopPlay(); return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNext(); return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                playPrev(); return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
